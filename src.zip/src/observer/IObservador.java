package observer;

public interface IObservador {
	void Actualizar();

}
